import json
import sys
from pathlib import Path

import h5py
import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import nisar_change_pipeline as P  # noqa: E402

REAL_NAME = ("NISAR_L2_PR_GCOV_009_072_D_079_4005_DHDH_A_20260102T045817_20260102T045836_"
             "X05010_N_P_J_001.h5")


def test_parse_real_filename():
    info = P.parse_scene_name(REAL_NAME)
    assert info["track"] == 72 and info["frame"] == 79 and info["direction"] == "D"
    assert info["pols"] == "DHDH" and info["start"].strftime("%Y-%m-%d") == "2026-01-02"


def test_parse_rejects_other_names():
    assert P.parse_scene_name("something_else.h5") is None


@pytest.mark.parametrize("bbox", [
    (10, 5, 9, 6), (10, 5, 11, 4), (0, 0, 5, 5), (-200, 0, 1, 1), (0, 0, float("nan"), 1), (0, 0, 1),
])
def test_bbox_validation_rejects(bbox):
    with pytest.raises(P.PipelineError):
        P.validate_bbox(bbox)


def test_bbox_ok():
    assert P.validate_bbox((100, 15, 100.2, 15.2)) == (100.0, 15.0, 100.2, 15.2)


def test_grid_and_area_consistent():
    tf, shape = P.make_grid((100, 15, 100.2, 15.2), 60.0)
    area = P.pixel_area_km2(tf, shape)
    total = float((area * np.ones(shape)).sum())
    expected = (0.2 * 111.32) * (0.2 * 111.32 * np.cos(np.radians(15.1)))
    assert total == pytest.approx(expected, rel=0.02)


def test_grid_too_large():
    with pytest.raises(P.PipelineError):
        P.make_grid((100, 15, 100.9, 15.9), 5.0)


def test_to_db_handles_bad_values():
    out = P.to_db(np.array([1.0, 0.1, 0.0, -1.0, np.nan, np.inf], dtype=np.float32))
    assert out[0] == pytest.approx(0.0) and out[1] == pytest.approx(-10.0, abs=1e-4)
    assert np.isnan(out[2:]).all()


def test_otsu_separates_two_modes():
    rng = np.random.default_rng(0)
    v = np.concatenate([rng.normal(-24, 1.5, 5000), rng.normal(-10, 2, 5000)])
    assert -22 < P.otsu_threshold(v) < -12


def test_otsu_needs_data():
    with pytest.raises(P.PipelineError):
        P.otsu_threshold(np.array([np.nan, -10.0]))


def test_classify_change_counts():
    base = np.full((10, 10), -10.0, dtype=np.float32)
    now = base.copy()
    now[:2, :] = -25.0            # 20 px new water
    base[9, :] = -25.0
    now[9, :] = -10.0             # 10 px water loss
    now[5, 5] = np.nan            # invalid pixel must be ignored
    area = np.ones((10, 1))
    r = P.classify_change(base, now, -18.0, 3.0, area)
    assert r["stats"]["gain_km2"] == 20 and r["stats"]["loss_km2"] == 10
    assert r["stats"]["water_km2"] == 20
    assert r["stats"]["valid_pct"] == 99.0


def test_demo_end_to_end(tmp_path):
    files = P.make_synthetic_gcov(tmp_path / "raw")
    out = P.run_process([str(f) for f in files], "Test Area!", None, P.DEMO_BBOX, "hhhh", "a",
                        60.0, "-18", 3.0, 5.0, tmp_path / "out")
    meta = json.loads((out / "meta.json").read_text())
    assert out.name == "test-area" and len(meta["frames"]) == 5
    water = [f["water_km2"] for f in meta["frames"]]
    assert water[3] > 4 * water[0] and water[4] < water[3]           # flood peaks then recedes
    assert meta["frames"][0]["gain_km2"] == 0
    for i in range(5):
        for kind in ("db", "water", "waterchange", "change"):
            assert (out / "frames" / f"{kind}_{i:03d}.png").stat().st_size > 0
    idx = json.loads((tmp_path / "out" / "index.json").read_text())
    assert [a["name"] for a in idx["aois"]] == ["test-area"]


def test_index_is_updated_not_duplicated(tmp_path):
    P._update_index(tmp_path, "a", "A")
    P._update_index(tmp_path, "b", "B")
    P._update_index(tmp_path, "a", "A2")
    idx = json.loads((tmp_path / "index.json").read_text())
    assert [(a["name"], a["title"]) for a in idx["aois"]] == [("a", "A2"), ("b", "B")]


def test_missing_polarization_message(tmp_path):
    files = P.make_synthetic_gcov(tmp_path / "raw")
    with pytest.raises(P.PipelineError, match="not present"):
        P.read_gcov_window(files[0], "VVVV", "A", P.DEMO_BBOX)


def test_outside_area_returns_none(tmp_path):
    files = P.make_synthetic_gcov(tmp_path / "raw")
    assert P.read_gcov_window(files[0], "HHHH", "A", (101.0, 15.0, 101.1, 15.1)) is None


def test_all_outside_area_gives_clear_error(tmp_path):
    files = P.make_synthetic_gcov(tmp_path / "raw")
    with pytest.raises(P.PipelineError, match="at least 2 dates"):
        P.run_process([str(f) for f in files], "x", None, (101.0, 15.0, 101.1, 15.1), "HHHH", "A",
                      60.0, "-18", 3.0, 5.0, tmp_path / "out")


def test_bad_mask_is_ignored(tmp_path):
    files = P.make_synthetic_gcov(tmp_path / "raw")
    with h5py.File(files[0], "r+") as f:
        f["science/LSAR/GCOV/grids/frequencyA/mask"][...] = 0   # would wipe everything
    arr, _, _ = P.read_gcov_window(files[0], "HHHH", "A", P.DEMO_BBOX)
    assert np.isfinite(arr).mean() > 0.5


def test_mixed_geometry_picks_largest_group(tmp_path):
    files = P.make_synthetic_gcov(tmp_path / "raw")
    scenes = P.collect_scenes(files)
    odd = P.Scene(scenes[0].path, 1, 99, "A", 1, scenes[0].start)
    kept = P.select_consistent_stack(scenes + [odd])
    assert {s.track for s in kept} == {72} and len(kept) == 5


def test_cli_errors_do_not_traceback(capsys):
    rc = P.main(["process", "--input", "nope", "--name", "x", "--bbox", "100", "15", "100.1", "15.1"])
    assert rc == 2 and "ERROR" in capsys.readouterr().err
