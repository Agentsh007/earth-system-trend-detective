# NISAR surface-change app - "Dancing with the SARs"

Track and visualize surface change (flooding, river/wetland change, crop cycles) from NISAR L-band radar backscatter.

## 1. Try it in 2 minutes (no data, no account)
```bash
pip install -r requirements.txt
python nisar_change_pipeline.py demo --out demo_output
python -m http.server 8000
# open http://localhost:8000/viewer/?data=../demo_output
```
The demo uses SYNTHETIC data (a river that floods and recedes, plus a crop field that brightens).

## 2. Run on real NISAR data
1. Create a free NASA Earthdata account and a bearer token: https://urs.earthdata.nasa.gov  (profile -> Generate Token).
2. `export EARTHDATA_TOKEN=...` (never commit it).
3. Pick a SMALL area (<= 1 degree per side), e.g. 0.2 x 0.2 degrees:
```bash
python nisar_change_pipeline.py search   --bbox W S E N --start 2026-06-17 --out scenes.json
python nisar_change_pipeline.py download --scenes scenes.json --data-dir data --max-files 6   # files are large, check size first
python nisar_change_pipeline.py inspect  data/<one-file>.h5            # confirm the layout matches the assumptions below
python nisar_change_pipeline.py process  --input data --name my-area --title "My area" \
        --bbox W S E N --pol HHHH --res-m 50 --out out
python -m http.server 8000     # open http://localhost:8000/viewer/?data=../out
```
Run `process` again with another `--name` and `--bbox` to add more areas; the viewer lists them all.

Useful options: `--water-threshold-db auto` (Otsu), `--change-threshold-db 3`, `--pol HVHV`, `--res-m 30` (smaller = sharper, slower).

## 3. What it computes
For each date vs. the first date: open water (dB threshold), water gained/lost, backscatter change in dB, changed area in km2.
Multilooking is done on linear power, then converted to dB. Areas use per-latitude pixel sizes.

## 4. Tested vs. NOT tested
Tested here (23 automated tests, plus a jsdom smoke test of the viewer): file-name parsing, validation, grid/area math, dB edge cases,
Otsu, change classification, full pipeline on synthetic GCOV-shaped HDF5, error handling, and viewer rendering logic.

NOT tested against live services/real files (the build environment cannot reach NASA servers):
- `search` and `download` (API calls are written against asf_search v14 but not executed).
- Reading a real NISAR GCOV file. Run `inspect` first; if it differs from the assumptions, fix the constants at the top of the script.

Assumptions to verify on a real file:
- A1 path `/science/LSAR/GCOV/grids/frequencyA/<POL>`, with `xCoordinates` ascending and `yCoordinates` descending.
- A2 CRS in dataset `projection` (value and/or attribute `epsg_code`).
- A3 `mask`: 0 = invalid, 255 = fill (ignored automatically if it would discard almost everything).
- A4 asf_search result fields `url`, `fileName`, `startTime`, `bytes` (read defensively).

## 5. Limits to state in your pitch
Provisional data; short time series (observations from 2026-06-17 onward); water detection by threshold misses flooded vegetation;
speckle noise at fine resolution; change is vs. the first date only; web overlays are accurate for areas up to ~1 degree.

## 6. Files
`nisar_change_pipeline.py` pipeline CLI | `viewer/index.html` map app | `tests/` pytest suite | `PROMPT.md` AI prompt | `demo_output/` prebuilt demo.
